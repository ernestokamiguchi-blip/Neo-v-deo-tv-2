package com.neon.video

import android.Manifest
import android.content.ContentUris
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.ListView
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.mediarouter.app.MediaRouteButton
import androidx.media3.common.MediaItem
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import com.google.android.gms.cast.MediaInfo
import com.google.android.gms.cast.MediaLoadRequestData
import com.google.android.gms.cast.MediaSeekOptions
import com.google.android.gms.cast.framework.CastButtonFactory
import com.google.android.gms.cast.framework.CastContext
import com.google.android.gms.cast.framework.CastSession
import com.google.android.gms.cast.framework.SessionManagerListener

class MainActivity : AppCompatActivity() {

    data class Vid(val id: Long, val title: String, val dur: Long, val mime: String) {
        val uri get() = ContentUris.withAppendedId(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, id)
        val url get() = VideoServer.urlFor(id, mime)
    }

    private lateinit var player: ExoPlayer
    private lateinit var server: VideoServer
    private lateinit var title: TextView
    private lateinit var status: TextView
    private var vids = listOf<Vid>()
    private var cur: Vid? = null
    private var dlna: Dlna.Dev? = null
    private var dlnaPlaying = false
    private var castCtx: CastContext? = null

    private fun castSession(): CastSession? = castCtx?.sessionManager?.currentCastSession?.takeIf { it.isConnected }

    private val castListener = object : SessionManagerListener<CastSession> {
        override fun onSessionStarting(s: CastSession) {}
        override fun onSessionStarted(s: CastSession, id: String) { onCastOn(s) }
        override fun onSessionStartFailed(s: CastSession, e: Int) { status.text = "Falha ao conectar na TV" }
        override fun onSessionEnding(s: CastSession) {}
        override fun onSessionEnded(s: CastSession, e: Int) { status.text = "Desconectado da TV"; keepOn(false) }
        override fun onSessionResuming(s: CastSession, id: String) {}
        override fun onSessionResumed(s: CastSession, was: Boolean) { onCastOn(s) }
        override fun onSessionResumeFailed(s: CastSession, e: Int) {}
        override fun onSessionSuspended(s: CastSession, r: Int) {}
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        setContentView(R.layout.activity_main)
        title = findViewById(R.id.title)
        status = findViewById(R.id.status)
        player = ExoPlayer.Builder(this).build()
        findViewById<PlayerView>(R.id.pv).player = player

        server = VideoServer(this)
        try { server.start(5000, false) } catch (e: Exception) { status.text = "Erro ao iniciar servidor local" }

        val route = findViewById<MediaRouteButton>(R.id.route)
        try {
            castCtx = CastContext.getSharedInstance(this)
            CastButtonFactory.setUpMediaRouteButton(applicationContext, route)
            castCtx?.sessionManager?.addSessionManagerListener(castListener, CastSession::class.java)
        } catch (e: Exception) { route.visibility = View.GONE }

        findViewById<Button>(R.id.dlna).setOnClickListener { pickDlna() }
        findViewById<Button>(R.id.rew).setOnClickListener { seek(-10) }
        findViewById<Button>(R.id.fwd).setOnClickListener { seek(10) }
        findViewById<Button>(R.id.tog).setOnClickListener { toggle() }
        findViewById<Button>(R.id.stop).setOnClickListener { stopTv() }
        findViewById<ListView>(R.id.list).setOnItemClickListener { _, _, i, _ -> playVideo(vids[i]) }
        ensurePerms()
    }

    private fun perms(): Array<String> =
        if (Build.VERSION.SDK_INT >= 33) arrayOf(Manifest.permission.READ_MEDIA_VIDEO, Manifest.permission.NEARBY_WIFI_DEVICES)
        else arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE)

    private fun ensurePerms() {
        val need = perms().filter { checkSelfPermission(it) != PackageManager.PERMISSION_GRANTED }
        if (need.isEmpty()) loadList() else requestPermissions(need.toTypedArray(), 1)
    }

    override fun onRequestPermissionsResult(rc: Int, p: Array<out String>, r: IntArray) {
        super.onRequestPermissionsResult(rc, p, r)
        loadList()
    }

    private fun fmt(ms: Long): String { val s = ms / 1000; return "${s / 60}:${(s % 60).toString().padStart(2, '0')}" }

    private fun loadList() {
        val out = ArrayList<Vid>()
        try {
            val m = MediaStore.Video.Media
            contentResolver.query(
                m.EXTERNAL_CONTENT_URI, arrayOf(m._ID, m.DISPLAY_NAME, m.DURATION, m.MIME_TYPE),
                null, null, "${m.DATE_ADDED} DESC"
            )?.use { c ->
                while (c.moveToNext()) out.add(
                    Vid(c.getLong(0), (c.getString(1) ?: "Vídeo").substringBeforeLast('.'), c.getLong(2), c.getString(3) ?: "video/mp4")
                )
            }
        } catch (e: Exception) { }
        vids = out
        status.text = if (out.isEmpty()) "Nenhum vídeo encontrado (ou permissão negada)" else "${out.size} vídeos • toque para tocar"
        findViewById<ListView>(R.id.list).adapter = object : ArrayAdapter<Vid>(this, android.R.layout.simple_list_item_2, android.R.id.text1, vids) {
            override fun getView(pos: Int, v: View?, parent: ViewGroup): View {
                val row = super.getView(pos, v, parent)
                row.findViewById<TextView>(android.R.id.text1).apply { text = vids[pos].title; setTextColor(0xFF00F0FF.toInt()) }
                row.findViewById<TextView>(android.R.id.text2).apply { text = fmt(vids[pos].dur); setTextColor(0xFF8B5CF6.toInt()) }
                return row
            }
        }
    }

    private fun keepOn(on: Boolean) {
        if (on) window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        else window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
    }

    private fun playVideo(v: Vid) {
        cur = v
        title.text = v.title
        val s = castSession()
        val d = dlna
        when {
            s != null -> { player.pause(); castLoad(s, v) }
            d != null -> {
                player.pause(); keepOn(true); status.text = "Enviando para ${d.name}..."
                Thread { Dlna.play(d.ctrl, v.url, v.title); dlnaPlaying = true }.start()
            }
            else -> { player.setMediaItem(MediaItem.fromUri(v.uri)); player.prepare(); player.play() }
        }
    }

    private fun onCastOn(s: CastSession) {
        dlna = null
        player.pause()
        cur?.let { castLoad(s, it) } ?: run { status.text = "TV conectada • escolha um vídeo" }
    }

    private fun castLoad(s: CastSession, v: Vid) {
        val rmc = s.remoteMediaClient ?: return
        val md = com.google.android.gms.cast.MediaMetadata(com.google.android.gms.cast.MediaMetadata.MEDIA_TYPE_MOVIE)
        md.putString(com.google.android.gms.cast.MediaMetadata.KEY_TITLE, v.title)
        val info = MediaInfo.Builder(v.url).setStreamType(MediaInfo.STREAM_TYPE_BUFFERED)
            .setContentType(v.mime).setMetadata(md).build()
        rmc.load(MediaLoadRequestData.Builder().setMediaInfo(info).setAutoplay(true).setCurrentTime(0L).build())
        keepOn(true)
        status.text = "Tocando na TV (Chromecast) • mantenha o app aberto"
    }

    private fun toggle() {
        val s = castSession()
        val d = dlna
        when {
            s != null -> s.remoteMediaClient?.togglePlayback()
            d != null -> Thread {
                if (dlnaPlaying) Dlna.pause(d.ctrl) else Dlna.resume(d.ctrl)
                dlnaPlaying = !dlnaPlaying
            }.start()
            else -> if (player.isPlaying) player.pause() else player.play()
        }
    }

    private fun seek(sec: Int) {
        val s = castSession()
        val d = dlna
        when {
            s != null -> s.remoteMediaClient?.let {
                it.seek(MediaSeekOptions.Builder().setPosition(maxOf(0L, it.approximateStreamPosition + sec * 1000L)).build())
            }
            d != null -> Thread { Dlna.seekBy(d.ctrl, sec) }.start()
            else -> player.seekTo(maxOf(0L, player.currentPosition + sec * 1000L))
        }
    }

    private fun stopTv() {
        dlna?.let { d -> Thread { Dlna.stop(d.ctrl) }.start() }
        dlna = null
        castCtx?.sessionManager?.endCurrentSession(true)
        keepOn(false)
        status.text = "Voltou a tocar no celular"
    }

    private fun pickDlna() {
        status.text = "Procurando TVs no Wi-Fi..."
        Dlna.discover(this) { list ->
            runOnUiThread {
                if (list.isEmpty()) { status.text = "Nenhuma TV DLNA encontrada. Confira o Wi-Fi."; return@runOnUiThread }
                status.text = "${list.size} TV(s) encontrada(s)"
                AlertDialog.Builder(this).setTitle("Escolha a TV")
                    .setItems(list.map { it.name }.toTypedArray()) { _, i ->
                        dlna = list[i]
                        castCtx?.sessionManager?.endCurrentSession(true)
                        status.text = "TV: ${list[i].name} • toque num vídeo"
                        cur?.let { playVideo(it) }
                    }.show()
            }
        }
    }

    override fun onDestroy() {
        castCtx?.sessionManager?.removeSessionManagerListener(castListener, CastSession::class.java)
        player.release()
        server.stop()
        super.onDestroy()
    }
}
