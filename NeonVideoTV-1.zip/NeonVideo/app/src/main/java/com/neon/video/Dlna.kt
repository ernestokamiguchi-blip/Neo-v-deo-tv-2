package com.neon.video

import android.content.Context
import android.net.wifi.WifiManager
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.HttpURLConnection
import java.net.InetAddress
import java.net.SocketTimeoutException
import java.net.URL

/** DLNA/UPnP: acha TVs Samsung, LG, Sony etc. na rede e manda o vídeo para elas. Chame fora da thread principal. */
object Dlna {
    data class Dev(val name: String, val ctrl: String)

    private const val NS = "urn:schemas-upnp-org:service:AVTransport:1"

    fun discover(ctx: Context, done: (List<Dev>) -> Unit) {
        Thread {
            val out = ArrayList<Dev>()
            val seen = HashSet<String>()
            val wm = ctx.applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
            val lock = wm.createMulticastLock("neon-dlna").apply { setReferenceCounted(false); acquire() }
            try {
                DatagramSocket().use { sock ->
                    sock.soTimeout = 1500
                    val sts = listOf(NS, "urn:schemas-upnp-org:device:MediaRenderer:1")
                    for (st in sts) {
                        val msg = ("M-SEARCH * HTTP/1.1\r\nHOST: 239.255.255.250:1900\r\nMAN: \"ssdp:discover\"\r\nMX: 2\r\nST: $st\r\n\r\n").toByteArray()
                        sock.send(DatagramPacket(msg, msg.size, InetAddress.getByName("239.255.255.250"), 1900))
                    }
                    val end = System.currentTimeMillis() + 4000
                    while (System.currentTimeMillis() < end) {
                        try {
                            val p = DatagramPacket(ByteArray(2048), 2048)
                            sock.receive(p)
                            val txt = String(p.data, 0, p.length)
                            val loc = Regex("(?i)location:\\s*(\\S+)").find(txt)?.groupValues?.get(1) ?: continue
                            if (seen.add(loc)) fetch(loc)?.let { out.add(it) }
                        } catch (e: SocketTimeoutException) { }
                    }
                }
            } catch (e: Exception) {
            } finally {
                try { lock.release() } catch (e: Exception) { }
            }
            done(out.distinctBy { it.ctrl })
        }.start()
    }

    private fun fetch(loc: String): Dev? = try {
        val c = URL(loc).openConnection() as HttpURLConnection
        c.connectTimeout = 2000; c.readTimeout = 2000
        val xml = c.inputStream.bufferedReader().readText()
        val name = Regex("<friendlyName>(.*?)</friendlyName>", RegexOption.DOT_MATCHES_ALL).find(xml)?.groupValues?.get(1)?.trim() ?: "TV"
        val svc = Regex("<service>(.*?)</service>", RegexOption.DOT_MATCHES_ALL).findAll(xml)
            .map { it.groupValues[1] }.firstOrNull { it.contains("AVTransport") }
        val cu = svc?.let { Regex("<controlURL>(.*?)</controlURL>").find(it)?.groupValues?.get(1)?.trim() }
        if (cu == null) null else Dev(name, URL(URL(loc), cu).toString())
    } catch (e: Exception) { null }

    private fun x(s: String) = s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replace("\"", "&quot;")

    private fun soap(ctrl: String, action: String, args: String): String? = try {
        val body = "<?xml version=\"1.0\"?><s:Envelope xmlns:s=\"http://schemas.xmlsoap.org/soap/envelope/\" " +
            "s:encodingStyle=\"http://schemas.xmlsoap.org/soap/encoding/\"><s:Body><u:$action xmlns:u=\"$NS\">" +
            "<InstanceID>0</InstanceID>$args</u:$action></s:Body></s:Envelope>"
        val c = URL(ctrl).openConnection() as HttpURLConnection
        c.connectTimeout = 3000; c.readTimeout = 5000
        c.requestMethod = "POST"; c.doOutput = true
        c.setRequestProperty("Content-Type", "text/xml; charset=\"utf-8\"")
        c.setRequestProperty("SOAPACTION", "\"$NS#$action\"")
        c.outputStream.use { it.write(body.toByteArray()) }
        val s = if (c.responseCode < 400) c.inputStream else c.errorStream
        s?.bufferedReader()?.readText()
    } catch (e: Exception) { null }

    fun play(ctrl: String, url: String, title: String) {
        soap(ctrl, "Stop", "")
        val didl = "<DIDL-Lite xmlns=\"urn:schemas-upnp-org:metadata-1-0/DIDL-Lite/\" xmlns:dc=\"http://purl.org/dc/elements/1.1/\" " +
            "xmlns:upnp=\"urn:schemas-upnp-org:metadata-1-0/upnp/\"><item id=\"0\" parentID=\"-1\" restricted=\"1\">" +
            "<dc:title>${x(title)}</dc:title><upnp:class>object.item.videoItem</upnp:class>" +
            "<res protocolInfo=\"http-get:*:video/mp4:*\">${x(url)}</res></item></DIDL-Lite>"
        soap(ctrl, "SetAVTransportURI", "<CurrentURI>${x(url)}</CurrentURI><CurrentURIMetaData>${x(didl)}</CurrentURIMetaData>")
        Thread.sleep(700)
        soap(ctrl, "Play", "<Speed>1</Speed>")
    }

    fun resume(ctrl: String) { soap(ctrl, "Play", "<Speed>1</Speed>") }
    fun pause(ctrl: String) { soap(ctrl, "Pause", "") }
    fun stop(ctrl: String) { soap(ctrl, "Stop", "") }

    fun seekBy(ctrl: String, delta: Int) {
        val r = soap(ctrl, "GetPositionInfo", "") ?: return
        val m = Regex("<RelTime>(\\d+):(\\d+):(\\d+)").find(r) ?: return
        val cur = m.groupValues[1].toInt() * 3600 + m.groupValues[2].toInt() * 60 + m.groupValues[3].toInt()
        val t = maxOf(0, cur + delta)
        val tgt = String.format("%02d:%02d:%02d", t / 3600, (t % 3600) / 60, t % 60)
        soap(ctrl, "Seek", "<Unit>REL_TIME</Unit><Target>$tgt</Target>")
    }
}
