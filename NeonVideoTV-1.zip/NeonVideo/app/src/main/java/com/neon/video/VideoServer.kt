package com.neon.video

import android.content.ContentUris
import android.content.Context
import android.provider.MediaStore
import fi.iki.elonen.NanoHTTPD
import fi.iki.elonen.NanoHTTPD.IHTTPSession
import fi.iki.elonen.NanoHTTPD.Response
import java.io.FileInputStream
import java.net.Inet4Address
import java.net.NetworkInterface

/** Servidor HTTP no celular: a TV baixa o vídeo daqui (com suporte a avançar/voltar). */
class VideoServer(private val ctx: Context) : NanoHTTPD(PORT) {

    companion object {
        const val PORT = 8765
        fun ip(): String {
            try {
                for (ni in NetworkInterface.getNetworkInterfaces()) {
                    for (a in ni.inetAddresses) {
                        if (!a.isLoopbackAddress && a is Inet4Address && a.isSiteLocalAddress) return a.hostAddress ?: ""
                    }
                }
            } catch (e: Exception) { }
            return "127.0.0.1"
        }
        fun urlFor(id: Long, mime: String): String {
            val ext = when {
                mime.contains("matroska") -> "mkv"
                mime.contains("webm") -> "webm"
                else -> "mp4"
            }
            return "http://${ip()}:$PORT/v/$id.$ext"
        }
    }

    private fun err(s: Response.Status, m: String): Response = NanoHTTPD.newFixedLengthResponse(s, "text/plain", m)

    override fun serve(session: IHTTPSession): Response {
        val id = Regex("/v/(\\d+)").find(session.uri)?.groupValues?.get(1)?.toLongOrNull()
            ?: return err(Response.Status.NOT_FOUND, "404")
        val uri = ContentUris.withAppendedId(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, id)
        val pfd = try { ctx.contentResolver.openFileDescriptor(uri, "r") } catch (e: Exception) { null }
            ?: return err(Response.Status.NOT_FOUND, "404")
        val total = pfd.statSize
        val mime = ctx.contentResolver.getType(uri) ?: "video/mp4"
        var start = 0L
        var end = total - 1
        var partial = false
        session.headers["range"]?.let { r ->
            Regex("bytes=(\\d*)-(\\d*)").find(r)?.let { m ->
                val a = m.groupValues[1]
                val b = m.groupValues[2]
                if (a.isNotEmpty()) {
                    start = a.toLong()
                    if (b.isNotEmpty()) end = minOf(b.toLong(), total - 1)
                } else if (b.isNotEmpty()) {
                    start = maxOf(0L, total - b.toLong())
                }
                partial = true
            }
        }
        if (start > end || start >= total) {
            pfd.close()
            return err(Response.Status.RANGE_NOT_SATISFIABLE, "416")
        }
        val fis = object : FileInputStream(pfd.fileDescriptor) {
            override fun close() { try { super.close() } finally { pfd.close() } }
        }
        fis.channel.position(start)
        val len = end - start + 1
        val res = NanoHTTPD.newFixedLengthResponse(
            if (partial) Response.Status.PARTIAL_CONTENT else Response.Status.OK, mime, fis, len
        )
        res.addHeader("Accept-Ranges", "bytes")
        if (partial) res.addHeader("Content-Range", "bytes $start-$end/$total")
        res.addHeader("transferMode.dlna.org", "Streaming")
        res.addHeader("contentFeatures.dlna.org", "DLNA.ORG_OP=01;DLNA.ORG_CI=0;DLNA.ORG_FLAGS=01700000000000000000000000000000")
        return res
    }
}
